import React from "react";
import MaterialTable from 'material-table';
import "./Cards.scss";
import CAtt from "./CAtt";

export const Table=() =>{
  const data =[{name:'Java',age:12,Percentage:100}]
  const columns = [{title:'Subject',field:'name'},{title:'Total',field:'age'},
  {title:'Attend',field:'age'},{title:'Percentage',field:'Percentage'}
]
  return(
    <div>
    <CAtt/>
    <div className="col-md-8 threey">
    <div className="twoy">
    <MaterialTable title="Attendance" 
    data={data}
    columns={columns}
    options={{
      search:false,paging:false
    }}
    />
    </div>
    </div></div>
  );
}

export default Table;