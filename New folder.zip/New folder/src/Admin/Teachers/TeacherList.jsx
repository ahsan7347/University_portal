import React from 'react';
import {useState} from "react";
import { DataGrid } from '@mui/x-data-grid';
import "./teachers.scss";
import {rows} from "../Home/Dummy";
import { DeleteOutline } from "@material-ui/icons";
import { Link } from "react-router-dom";
export default function TList() {
  
  const [data,setData] = useState(rows);

  const handleDelete =(id)=>{
    setData(data.filter((item)=>item.id !== id ));
  };
const columns = [
  { field: 'id', headerName: 'ID', width: 100 },
  { field: 'name', headerName: 'Name', width: 70
  //    renderCell: (params) => {
  //   return (
  //     <div className="userListUser">
  //       <img className="userListImg" src={params.row.avatar} alt="" />
  //       {params.row.username}
  //     </div>
  //   );
  // }, 
},
  { field: 'email', headerName: 'Email', width: 130 },
  {
    field: 'depart',
    headerName: 'Department',
    width: 190,
  },

  {
    field: "action",
    headerName: "Action",
    width: 150,
    renderCell: (params) => {
      return (
        <div>
        <a href={"/teacherview"}>
        <button className="userListEdit">View</button>
        </a>
          <a href={"/teacheredit"}>
            <button className="userListEdit">Edit</button>
          </a>
          <DeleteOutline className="userListDelete" onClick={() =>handleDelete(params.row.id)}/>

        </div>
        
    );
    },
  },

];




  return (
    
    <div className="md-col-8 op">
    <div className="set">
    <div style={{ height: 400, width: '70%' }}>
    <a href="/addnewteacher">
            <button className="userAddButton">Add New</button>
          </a>
    <DataGrid
        rows={data}
        columns={columns}
        disableSelectionOnClick
        pageSize={8}
        checkboxSelection
      />
    </div></div></div>
    
  );
}