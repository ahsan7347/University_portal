import React from "react";
import "./style.scss";
import admicon from "../Pics/admicon.jpg";

const Admin = () => 
  {

    return(
      <div className="base-container">
      <div className="header"><h1>UNIVERSITY OF CALIFORNIA</h1></div>
      <div className="content">
      <div className="image">
          <img src={admicon} />
        </div>
        <div className="form">
          <div className="form-group">
            <label htmlFor="username">CNIC </label>
            <input type="number" name="cnic" placeholder="Cnic No" required/>
          </div>
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input type="password" name="password" placeholder="Password" required/>
          </div>
        </div>
      </div>
      <div className="footer">
        <button type="submit" className="btn">
          Login
        </button>
      </div>
    </div>
  );
}

export default Admin;