import React from "react";
import Std from "./Student";
import Tec from "./Teacher";
import Adm from "./Admin";
import {BrowserRouter as Switch,Route,Router,Link} from "react-router-dom";
import Signup from "./SignUp";

export default function Log(){
    return(
    <div className="Apps">
    <router> 
    <Switch>
    <Route exact path={'/'}>  <Std/> </Route>
    <Route exact path={'/login'}>  <Std/> </Route>
    <Route exact path={'/signup'}>  <Signup/> </Route>
    <Route exact path={'/teacherlogin'}>  <Tec/> </Route>
    <Route exact path={'/adminlogin'}>  <Adm/> </Route>
    </Switch>
    </router>
    </div>
  );
}