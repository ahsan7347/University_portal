export const rows = [
    { id: 1, name: 'Shani', email: 'xhani@gmail.com', depart: 'CS'  },
    { id: 2, name: 'Shani', email: 'xhani@gmail.com', depart: 'CS'  },
    { id: 3, name: 'Shani', email: 'xhani@gmail.com', depart: 'BBA'  },
    { id: 4, name: 'Shani', email: 'xhani@gmail.com', depart: 'ENG'  },
    { id: 5, name: 'Shani', email: 'xhani@gmail.com', depart: 'COM'  },
  ];
  
  export const userRows = [{ id: 1, name: 'Shani', email: 'xhani@gmail.com', depart: 'CS' ,cnic: 33110099 , no:11223344 } ];
  
  
  export const userData = [
    {
      name: "Jan",
      "Active User": 4000,
    },
    {
      name: "Feb",
      "Active User": 3000,
    },
    {
      name: "Mar",
      "Active User": 5000,
    },
    {
      name: "Apr",
      "Active User": 4000,
    },
    {
      name: "May",
      "Active User": 3000,
    },
    {
      name: "Jun",
      "Active User": 2000,
    },
    {
      name: "Jul",
      "Active User": 4000,
    },
    {
      name: "Agu",
      "Active User": 3000,
    },
    {
      name: "Sep",
      "Active User": 4000,
    },
    {
      name: "Oct",
      "Active User": 1000,
    },
    {
      name: "Nov",
      "Active User": 4000,
    },
    {
      name: "Dec",
      "Active User": 3000,
    },
  ];
  