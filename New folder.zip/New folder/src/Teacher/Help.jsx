import React from "react";
import "./new.scss";

const Help = () => 
  {
      return(
<div > 
<div className="col-md-8 vom"> 
<div className="vc">
<h1> Help </h1> <br/>
<p> It is easy to opearte this portal , having some menu's in side bar you can check more than
things daily </p> <p> If you are feeling hard to opearte than plz watch our this video to understand 
how to use portal </p> <br/>
<a href="" target="_blank"> Click To See </a> <br/>
<p> Or You get any trouble , 
Please contact our Team Email:xhanialee@gmail.com </p>
</div></div> </div>
      );
    }

export default Help;