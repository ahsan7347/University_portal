import React from 'react';
import PersonIcon from '@material-ui/icons/Person';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import DashboardIcon from '@material-ui/icons/Dashboard';
export const navT=
[
  {
title: "Dashboard",
icon: <DashboardIcon/>,
link: "/home"
  },
  {
title: "Students",
icon: <PersonIcon/>,
link: "/students"
  },
  {
title: "Teachers",
icon: <PersonIcon/>,
link: "/teachers"
  },
  {
    title: "Challans",
    icon: <PersonIcon/>,
    link: "/accounts"
      },
      {
        title: "Logout",
        icon: <ExitToAppIcon/>,
        link: "/iii"
          },
]  