import React from "react";
import Sidebar from "./Sidebar";

import User from "../Students/EditStudent"
import UserList from "../Students/StudentList";
import StudentView from "../Students/ViewStudent";
import Newstudent from "../Students/AddStudent";

import TList from "../Teachers/TeacherList";
import TEdit from "../Teachers/EditTeacher";
import TView from "../Teachers/TeacherView";
import Newteacher from "../Teachers/AddTeacher";


// import Aview from "./Accounts/Aview";
// import Aedit from "./Accounts/AEdit";
// import ASingle from "./Accounts/Single";
// import Newaccountant from "./Accounts/newaccountant";

import FeaturedInfo from "./Feature";
import Chart from "./Chart";
import {BrowserRouter as Switch,Route,Router,Link} from "react-router-dom";
import "./Ad.scss";
import SetCou from "../Teachers/SetCourses";
import Sub from "../Teachers/Sub";
export default function Index(){
  return(
    
    <div className="Apps">
     <router> 
     <Switch>
     <Sidebar/>

     <Route exact path={'/'}>  <FeaturedInfo/> <Chart /> </Route>
     <Route exact path={'/home'}>  <FeaturedInfo/> <Chart />  </Route>
     <Route exact path={'/students'}>  <UserList/> </Route>
     <Route exact path={'/edit'}>  <User/> </Route> 
     <Route exact path={'/studentview'}>  <StudentView/> </Route>
     <Route exact path={'/addnewstudent'}>  <Newstudent/> </Route>

     <Route exact path={'/teachers'}>  <TList/> </Route>
     <Route exact path={'/teacheredit'}>  <TEdit/> </Route>
     <Route exact path={'/teacherview'}>  <TView/> </Route>
     <Route exact path={'/addnewteacher'}>  <Newteacher/> </Route>
     <Route exact path={'/setcourses'}>  <SetCou/> </Route>
     <Route exact path={'/subjects'}>  <Sub/> </Route>

     {/* <Route exact path={'/accounts'}>  <Aview/> </Route> 
     <Route exact path={'/accountsedit'}>  <Aedit/> </Route>
     <Route exact path={'/accountantsview'}>  <ASingle/> </Route>
     <Route exact path={'/addnewaccountant'}>  <Newaccountant/> </Route> */}
     
     </Switch>
     </router>
     </div>
  );
}