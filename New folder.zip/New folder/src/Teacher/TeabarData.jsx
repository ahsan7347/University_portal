import React from 'react';
import "./new.scss";
import {navT} from "./navT";


function TeabarData  () {
  return(
    <div>
    
    <div className="headingm">
    <h1> <i> Welcome to University Of California </i> </h1>
    <span className="sense">Mr.Altaf Abro</span>
    </div>
    <div className="row">
    <div className="col-md-4 SideBarMenuu">
    <div className="Sidebar">
    <ul className="SidebarList">
    {navT.map((val, key) => {
    return(
      <li key={key}
      className="row"
      id = {window.location.pathname == val.link ? "active" : ""}
       onClick={() => { 
        window.location.pathname = val.link;
      }}>



      <div id = "icon">
      {val.icon}
      </div>  

<div id = "title"> {val.title}
</div>

      </li>
    );
  }
)
  }
  </ul>
  <div className="footer"> 
  </div>
  </div>
  </div>
  </div>
  
  </div>
  );
}
export default TeabarData;