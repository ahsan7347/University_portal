import React from "react";
import TeabarData from "./TeabarData";
import Arrr from "./Arrr";
import Tprof from "./Tprof";
import AddMarks from "./Addmarks";
import Marks from "./Marks";
import AddAttened from "./AddAttened";
import Courses from "./Ocourse";
import Help from "./Help";
import navT from "./navT";
import Attends from "./At"; 
import "./new.scss";
import Tcard from "./Tcard";
import Adm from "../Login/Admin";
import {BrowserRouter as Switch,Route,Router,Link} from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import Tec from "../Login/Teacher";


export default function IndexT(){
   return(
     <div className="Apps">
     <router> 
     <Switch>
     <TeabarData/>
     <Link to="/"><Route exact path={'/'}>     {Arrr.map(function ncard(val){
      return(
        <Tcard
        imgsrc={val.imgsrc}
        title={val.title}
        link={val.link}
        />
      );
    })
    }
    </Route></Link>
    <Link to="/teachhome"> <Route exact path={'/teachhome'}>     {Arrr.map(function ncard(val){
       return(
         <Tcard
         imgsrc={val.imgsrc}
         title={val.title}
         link={val.link}
         />
       );
     })
     }
     </Route> </Link>
     <Route exact path={'/teacherprofile'}>  <Tprof/> </Route>
     <Route exact path={'/viewcourses'}>  <Courses/> </Route>   
     <Route exact path={'/help'}>  <Help/> </Route>
     <Route exact path={'/addmarks'}>  <AddMarks/> </Route>
     <Route exact path={'/data'}>  <Marks/> </Route>
     <Route exact path={'/addattendance'}>  <AddAttened/> </Route>
     <Route exact path={'/addatt'}>  <Attends/> </Route>
     <Route exact path={'/teacherlogin'} > <Tec/></Route>
     </Switch>
     </router>
     </div>
   );
 }