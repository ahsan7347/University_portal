import React from "react";
import MaterialTable from 'material-table';
import AddAttened from "./AddAttened";
import "./new.scss";
const  Attends=()=>{
    const data =[{name:'Java' , id:11 }]
    const columns = [{title:'Course_ID',field:'id'},{title:'Name',field:'name'}
  ]

    return(<div>
        <AddAttened/>
        <div className="col-md-8 threee">
        <div className="twon">
        <MaterialTable title="Attendance"
        data={data}
        columns={columns}
        options={{
            selection: true,
            search:false,paging:false,checked: true
            }} /> </div></div> <div className="btb"> <button type="button" className="btn">Upload</button></div></div>
    );
}
export default Attends;