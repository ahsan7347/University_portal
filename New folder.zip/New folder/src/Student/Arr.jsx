import React from "react";

export const Arr = [
  {
imgsrc: "https://toppng.com/uploads/preview/dashboard-svg-icon-free-dashboard-icon-11553444664o1utwdkesz.png",
title: "Dashboard",
link: "/studentdashboard"
  },
  {
    imgsrc: "https://freesvg.org/img/abstract-user-flat-4.png",
    title: "Profile",
    link: "/studentprofile"
      },
      {
        imgsrc: "https://image.shutterstock.com/image-vector/attendance-vector-line-icon-260nw-597358928.jpg",
        title: "Attendance",
        link: "/studentattendance"
          },
          {
          
            imgsrc: "https://cdn.iconscout.com/icon/premium/png-512-thumb/marksheet-3287956-2754054.png",
            title: "View Courses",
            link: "/studentcourse"
              },
          {
          
            imgsrc: "https://cdn.iconscout.com/icon/premium/png-512-thumb/marksheet-3287956-2754054.png",
            title: "Marksheet",
            link: "/studentmarksheet"
              },
              {
                
                imgsrc: "https://image.shutterstock.com/image-vector/vector-cartoon-illustration-document-challan-260nw-1805859397.jpg",
                title: "Challans",
                link: "/studentchallan"
                  },
                  {
                   
                    imgsrc: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/VisualEditor_-_Icon_-_Help.svg/1200px-VisualEditor_-_Icon_-_Help.svg.png",
                    title: "Help",
                    link: "/studenthelp"
                      },
                      {
                    
                        imgsrc: "https://cdn.iconscout.com/icon/premium/png-256-thumb/logout-2478749-2073390.png",
                        title: "Logout",
                        link: "/studentlogout"
                          },
  
]

export default Arr;