import React from "react";
import MaterialTable from 'material-table';
import "./new.scss";

export const Courses=() =>{
  const data =[{name:'SQL' , id:11 }]
  const columns = [{title:'Course_ID',field:'id'},{title:'Name',field:'name'}
]
  return(
    <div className="col-md-8 z">
    <div className="y">
    <MaterialTable title=" COURSES"
    data={data}
    columns={columns}
    options={{
      search:false,paging:false
    }}
    />
    </div>
    </div>
  );
}

export default Courses;