import React from "react";
import "./index.css";
import './App.css';
import "bootstrap/dist/css/bootstrap.min.css";
import Log from "./Login/Log";
import IndexS from "../src/Student/IndexS"
import IndexT from "../src/Teacher/IndexT"
import Index from "../src/Admin/Home/Index"

function App() {
    return(
    <>
<Log/>
</>
     );
   }
export default App;
