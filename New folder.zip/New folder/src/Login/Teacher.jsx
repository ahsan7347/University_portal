import React from "react";
import "./style.scss";
import dp from "../Pics/dp.jpg";

const Tec = () => 
  {
    return(
      <div className="base-container">
      <div className="header"><h1>UNIVERSITY OF CALIFORNIA</h1></div>
      <div className="content">
      <div className="image">
          <img src={dp} />
        </div>
        <div className="form">
          <div className="form-group">
            <label htmlFor="username">CNIC </label>
            <input type="number" name="cnic" placeholder="Cnic No" />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input type="password" name="password" placeholder="Password" />
          </div>
        </div>
      </div>
      <div className="footer">
        <button type="submit" className="btn">
          Login
        </button>
      </div>
    </div>
    );
}

export default Tec;