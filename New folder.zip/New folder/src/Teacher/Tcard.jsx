import React from "react";
import "./new.scss";
function Tcard(props) {
    return(
        <div className="col-md-8 cars">
        <div className="start">
        <div className="cards">
        <div className="card">
        <a href={props.link} className="bt">
        <img src={props.imgsrc} alt="" className="card_img"/> </a> 
        <div className="card_info">
        <span className="card_category"> {props.title} </span> </div> 
        </div>
        </div>
        </div>
        </div>
        
    );
}
export default Tcard;