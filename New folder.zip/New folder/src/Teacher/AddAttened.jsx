import React from "react";
import Select from "@material-ui/core/Select";
import FormControl from "@material-ui/core/FormControl";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import {Link} from "react-router-dom";
import "./new.scss";

const AddAttened =() =>{

    const[value,setValue] = React.useState('')
    const handleChange = (event) => {
        setValue(event.target.value)
    }
    return(
<div className="col-md-8 w">
<FormControl fullWidth>
<div className="wid">
  <InputLabel id="demo-simple-select-label">Department</InputLabel>
  <Select
    labelId="demo-simple-select-label"
    id="demo-simple-select"
    value={value}
    label="Age"
    onChange={handleChange}
  > 
    <MenuItem value={'C'}>Computer Science</MenuItem>
    <MenuItem value={'T'}>BBA</MenuItem>
  </Select> </div>
</FormControl>
<FormControl fullWidth>
<div className="wid">
  <InputLabel id="demo-simple-select-label">Subject</InputLabel>
  <Select
    labelId="demo-simple-select-label"
    id="demo-simple-select"
    value={value}
    label="Age"
    onChange={handleChange}
  > 
    <MenuItem value={'C'}>Java</MenuItem>
    <MenuItem value={'T'}>Accounting</MenuItem>
  </Select> </div>
</FormControl>
<FormControl fullWidth>
<div className="wid">
  <InputLabel id="demo-simple-select-label">No Of Classes</InputLabel>
  <Select
    labelId="demo-simple-select-label"
    id="demo-simple-select"
    value={value}
    label="Age"
    onChange={handleChange}
  > 
    <MenuItem value={'C'}>1</MenuItem>
    <MenuItem value={'T'}>2</MenuItem>
  </Select> </div>
</FormControl>

<Link to='/addatt'>
 <button type="button" className="btn">OK</button>
  </Link>  
  </div>
);}



    export default AddAttened;