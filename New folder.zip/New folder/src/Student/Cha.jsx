import React from "react";
import {Link} from "react-router-dom";
import "./Cards.scss";

const Cha = () => 
  {
      return(
<div > 
<div className="col-md-8 ony"> 
<div className="ch">
<h3 className="head"> Challan </h3>
<Link to='./challans'> <button type="button" className="btn">
View Challan
</button> 
 </Link>
 <div className="upload">
 <input type="file"/> <div> <button type="button" className="btn">
 Upload
 </button> </div> </div>
</div></div></div>
      );
    }

export default Cha;