import React from "react";
import MaterialTable from 'material-table';
import "./Cards.scss";

export const Course=() =>{
  const data =[{name:'Java' , id:11 }]
  const columns = [{title:'Course_ID',field:'id'},{title:'Name',field:'name'}
]
  return(
    <div className="col-md-8 threem">
    <div className="twom">
    <MaterialTable title="OFFERED COURSES"
    data={data}
    columns={columns}
    options={{
      search:false,paging:false
    }}
    />
    </div>
    </div>
  );
}

export default Course;