import React from "react";
import MaterialTable from 'material-table';
import SetCou from "./SetCourses";
const  Sub=()=>{
    const data =[{name:'Java' , id:11 }]
    const columns = [{title:'Course_ID',field:'id'},{title:'Name',field:'name'}
  ]

    return(<div>
        <SetCou/>
        <div className="col-md-8 tx">
        <div className="tx">
        <MaterialTable title="Set Courses"
        data={data}
        columns={columns}
        options={{
            selection: true,
            search:false,paging:false,checked: true
            }} /> </div></div> 
            <div className="bm"> 
            <button type="button" className="btnu">Upload</button>
            </div></div>
    );
}
export default Sub;