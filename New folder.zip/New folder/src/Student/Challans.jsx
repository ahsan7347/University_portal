import React from "react";
import "./Cards.scss";
// import Table from "react-table";

const Challans = () => 
  {
      return(<div> 
 
        
    <h1>OK</h1>
         </div> 
      );
    }
 export default Challans;   