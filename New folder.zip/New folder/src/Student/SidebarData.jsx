import React from 'react';
import './navbar.scss';
import {nav} from './Navbar';

function SidebarData  () {
  return(
    <div>
    
    <div className="headingy">
    <h1> <i> Welcome to University Of California </i> </h1>
    <span className="sen">Mr.Ahsan Ali</span>
    </div>
    <div className="row">
    <div className="col-md-4 SideBarMenu">
<div className="Sidebar">
  <ul className="SidebarList">
  {nav.map((val, key) => {
    return(
      <li key={key}
      className="row"
      id = {window.location.pathname == val.link ? "active" : ""}
       onClick={() => { 
        window.location.pathname = val.link;
      }}>



      <div id = "icon">
      {val.icon}
      </div>  

<div id = "title"> {val.title}
</div>

      </li>
    );
  }
)
  }
  </ul>
  <div className="footer"> 
  </div>
  </div>
  </div>
  </div>
  </div>
  );
}
export default SidebarData;