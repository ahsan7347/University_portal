import React from "react";
import "./Cards.scss";
import abcd from "../Pics/abcd.jpg";

const Prof = () => 
  {
      return(
          <div>
          <div className="col-md-8 pop"> 
 <img src={abcd} alt="" className="imgs" /> 
 <div className="len">
<div className="formm"> 
<label className="username"> Name :  </label> <label className="usernames"> xyz  </label> <br/>
<label className="username"> FatherName :  </label> <label className="usernames"> xyz  </label> <br/>
<label className="username"> Caste :  </label> <label className="usernames"> xyz  </label> <br/>
<label className="username"> Program :  </label> <label className="usernames"> xyz  </label> <br/>
<label className="username"> DOB :  </label> <label className="usernames"> xyz  </label> <br/>
<label className="username"> Email :  </label> <label className="usernames"> xyz  </label> <br/>
<label className="username"> MobileNo :  </label> <label className="usernames"> xyz  </label> <br/>
</div>
</div></div>
</div>
      );
    }
    export default Prof;