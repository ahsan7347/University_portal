import React from "react";
import Card from "./Card";
import Prof from "./Prof";
import Cha from "./Cha";
import Hel from "./Hel";
import Table from "./Attend";
import Arr from "./Arr";
import Course from "./Cour";
import CAtt from "./CAtt";
import CMar from "./CMar"
import Marksheet from "./Marksheet";
import Challans from "./Challans";
import "./Cards.scss";
import SidebarData from "./SidebarData";
import {BrowserRouter as Switch,Route,Router,Link} from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

export default function IndexS(){
    return(
            <div className="Apps">
    <router> 
    <Switch>
    <SidebarData/>
    <Route exact path={'/'}>     {Arr.map(function ncard(val){
      return(
        <Card
        imgsrc={val.imgsrc}
        title={val.title}
        link={val.link}
        />
      );
    })
    }
    </Route>
    <Route exact path={'/studentdashboard'}>     {Arr.map(function ncard(val){
      return(
        <Card
        imgsrc={val.imgsrc}
        title={val.title}
        link={val.link}
        />
      );
    })
    }
    </Route>

        
          <Route exact path={'/studentprofile'}>  <Prof/> </Route>
          <Route exact path={'/studentcourse'}>  <Course/> </Route>
          <Route exact path={'/studentchallan'}> <Cha/> </Route>
          <Route exact path={'/studentattendance'}>  <CAtt/> </Route>
          <Route exact path={'/viewatt'}>  <Table/> </Route>
          <Route exact path={'/viewmark'}>  <Marksheet/> </Route>
          <Route exact path={'/studentmarksheet'}>  <CMar/> </Route>
          <Route exact path={'/studenthelp'}>  <Hel/> </Route>
          <Route exact path={'/challans'}>  <Challans/> </Route>
    </Switch>
    </router>
    </div>
  );
}