import React from "react";
import Select from "@material-ui/core/Select";
import FormControl from "@material-ui/core/FormControl";
import InputLabel from "@material-ui/core/InputLabel";
import {Link} from "react-router-dom";
import MenuItem from "@material-ui/core/MenuItem";
import "./new.scss";
const AddMarks =() =>{

    const[value,setValue] = React.useState('')
    const handleChange = (event) => {
        setValue(event.target.value)
    }
    return(
<div className="col-md-8 win">
<FormControl fullWidth>
<div className="wid">
  <InputLabel id="demo-simple-select-label">Department</InputLabel>
  <Select
    labelId="demo-simple-select-label"
    id="demo-simple-select"
    value={value}
    label="Age"
    onChange={handleChange}
  > 
    <MenuItem value={'C'}>Computer Science</MenuItem>
    <MenuItem value={'T'}>BBA</MenuItem>
  </Select> </div>
</FormControl>
<FormControl fullWidth>
<div className="wid">
  <InputLabel id="demo-simple-select-label">Subject</InputLabel>
  <Select
    labelId="demo-simple-select-label"
    id="demo-simple-select"
    value={value}
    label="Age"
    onChange={handleChange}
  > 
    <MenuItem value={'C'}>Java</MenuItem>
    <MenuItem value={'T'}>Accounting</MenuItem>
  </Select> </div>
</FormControl>

<Link to="/data">
<button type="button" className="btn">Select</button> </Link>
 </div>
    );}


    export default AddMarks;