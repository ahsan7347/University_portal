import React from "react";
import "./new.scss";
import abcd from "../Pics/abcd.jpg";

const Tprof = () => 
  {
      return(
          <div>
<div className="col-md-8 x">
 <img src={abcd} alt="" className="imgn" /> <span> <p >Picture </p></span> 
<div className="forms"> 
<label className="username"> Name :  </label> <label className="usernames"> xyz  </label> <br/>
<label className="username"> FatherName :  </label> <label className="usernames"> xyz  </label> <br/>
<label className="username"> Caste :  </label> <label className="usernames"> xyz  </label> <br/>
<label className="username"> Program :  </label> <label className="usernames"> xyz  </label> <br/>
<label className="username"> DOB :  </label> <label className="usernames"> xyz  </label> <br/>
<label className="username"> Email :  </label> <label className="usernames"> xyz  </label> <br/>
<label className="username"> MobileNo :  </label> <label className="usernames"> xyz  </label> <br/>
</div>
</div> </div>
      );
    }
    export default Tprof;