// import React from "react";
// import MaterialTable from 'material-table';
// import CMar from "../../Student/CMar";
// import Marksheet from "../../Student/Marksheet";

// export const Marksh=() =>{
//   return(
//     <>
//     <CMar/>
    
//     </>
//   );
// }

// export default Marksh;