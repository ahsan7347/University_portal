import React from "react";
import MaterialTable from 'material-table';
import "./Cards.scss";
import CMar from "./CMar";

export const Marksheet=() =>{
  const data =[{id:'CS1',name:'Java',total:100,obtained:80,status:'Pass',gp:4},
  {id:'CS2',name:'Assembly',total:100,obtained:80,status:'Pass',gp:4}]
  const columns = [{title:'Course-ID',field:'id'},{title:'Name',field:'name'},
  {title:'Total Marks',field:'total'},{title:'Obtained',field:'obtained'},
  {title:'Status',field:'status'},{title:'GPA',field:'gp'}
]
  return(
    <div>
    <CMar/>
    <div className="col-md-8 threes">
    <div className="twos">
    <MaterialTable title="Marksheet" 
    data={data}
    columns={columns}
    options={{
      paging:false, search:false
    }}
    />
    </div></div>
    </div>
  );
}

export default Marksheet;