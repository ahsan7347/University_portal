import React from 'react';
import PersonIcon from '@material-ui/icons/Person';
import AssignmentIcon from '@material-ui/icons/Assignment';
import ChromeReaderModeIcon from '@material-ui/icons/ChromeReaderMode';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import DashboardIcon from '@material-ui/icons/Dashboard';
import MonetizationOnIcon from '@material-ui/icons/MonetizationOn';
import HelpOutlineIcon from '@material-ui/icons/HelpOutline';
export const nav=
[
  {
  title: "Dashboard",
icon: <DashboardIcon/>,
link: "/studentdashboard"
  },
  {
title: "Profile",
icon: <PersonIcon/>,
link: "/studentprofile"
  },
  {
title: "Attendance",
icon: <AssignmentIcon/>,
link: "/studentattendance"
  },
  {
    title: "View Courses",
    icon: <ChromeReaderModeIcon/>,
    link: "/studentcourse"
      },
  {
    title: "Marksheet",
    icon: <ChromeReaderModeIcon/>,
    link: "/studentmarksheet"
      },
      {
        title: "Challans",
      icon: <MonetizationOnIcon/>,
      link: "/studentchallan"
        },
        {
          title: "Help",
        icon: <HelpOutlineIcon/>,
        link: "/studenthelp"
          },
      {
        title: "Logout",
        icon: <ExitToAppIcon/>,
        link: "/studentlogout"
          },
]  
