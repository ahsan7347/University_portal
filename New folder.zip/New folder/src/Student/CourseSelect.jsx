import React from "react";
import Select from "@material-ui/core/Select";
import FormControl from "@material-ui/core/FormControl";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import "./Cards.scss";

const CMar =() =>{

    const[value,setValue] = React.useState('')
    const handleChange = (event) => {
        setValue(event.target.value)
    }
    return(
<div className="col-md-8 marc">
<FormControl fullWidth>
<div className="widosy">
  <InputLabel id="demo-simple-select-label">Semester</InputLabel>
  <Select
    labelId="demo-simple-select-label"
    id="demo-simple-select"
    value={value}
    label="Age"
    onChange={handleChange}
  > 
    <MenuItem value={'a'}>First</MenuItem>
    <MenuItem value={'b'}>Second</MenuItem>
    <MenuItem value={'c'}>Third</MenuItem>
    <MenuItem value={'d'}>Fourth</MenuItem>
    <MenuItem value={'e'}>Fifth</MenuItem>
    <MenuItem value={'f'}>Sixth</MenuItem>
    <MenuItem value={'g'}>Seventh</MenuItem>
    <MenuItem value={'h'}>Eighth</MenuItem>
  </Select> </div>
</FormControl>

 <button type="button" className="btn">OK</button>  
  </div>
);}



    export default CMar;