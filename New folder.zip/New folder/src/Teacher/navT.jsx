import React from 'react';
import PersonIcon from '@material-ui/icons/Person';
import AssignmentIcon from '@material-ui/icons/Assignment';
import ChromeReaderModeIcon from '@material-ui/icons/ChromeReaderMode';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import DashboardIcon from '@material-ui/icons/Dashboard';
import MonetizationOnIcon from '@material-ui/icons/MonetizationOn';
import HelpOutlineIcon from '@material-ui/icons/HelpOutline';
export const navT=
[
  {
title: "Dashboard",
icon: <DashboardIcon/>,
link: "/teachhome"
  },
  {
title: "Profile",
icon: <PersonIcon/>,
link: "/teacherprofile"
  },
  {
title: "Add Attendance",
icon: <AssignmentIcon/>,
link: "/addattendance"
  },
  {
    title: "Add Marks",
    icon: <ChromeReaderModeIcon/>,
    link: "/addmarks"
      },
      {
        title: "View Courses",
      icon: <MonetizationOnIcon/>,
      link: "/viewcourses"
        },
        {
          title: "Help",
        icon: <HelpOutlineIcon/>,
        link: "/help"
          },
      {
        title: "Logout",
        icon: <ExitToAppIcon/>,
        link: "/teacherlogin"
          },
]  
