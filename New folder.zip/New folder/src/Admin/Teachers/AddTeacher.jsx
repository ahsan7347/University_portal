import React from "react";
import "./teachers.scss";
export default function Newteacher() {
  return (
      <form>
      <div className="md-col-8 new">
      <div class="container">
        <h1>Add New</h1>
        
        <label ><b>First Name:</b></label>
        <input type="text" placeholder="First Name" className="email"  required/>
        <label ><b>Last Name:</b></label>
        <input type="text" placeholder="Last Name" className="email"  required/>
        <label ><b>CNIC:</b></label>
        <input type="number" placeholder="CNIC" className="email"  required/>
        <label ><b>Email</b></label>
        <input type="email" placeholder="Enter Email" className="email"  required/>
        <label ><b>Qualification</b></label>
        <input type="text" placeholder="Degree Name" className="email"  required/>
        <label ><b>University Name</b></label>
        <input type="text" placeholder="Uni" className="email"  required/>
        <label ><b>CGPA:</b></label>
        <input type="number" placeholder="CGPA" className="email"  required/>
        <label> <b> Gender: </b></label> <br/>
        <div className="rad">
        <label for="male">Male</label>
         <input type="radio" name="gender" id="male" value="male" />
         <label for="female">Female</label>
            <input type="radio" name="gender" id="female" value="female" />
            <label for="other">Other</label>
            <input type="radio" name="gender" id="other" value="other" /> </div>
            
        <label ><b>Mobile No:</b></label>
        <input type="number" placeholder="Mobile No" className="email"  required/>
        <label ><b>Domicile</b></label>
        <input type="text" placeholder="Domicile District" className="email"  required/>
    
        <label ><b>Password</b></label>
        <input type="password" placeholder="Enter Password" className="psw"  required/>
    
        <label ><b>Repeat Password</b></label>
        <input type="password" placeholder="Repeat Password" className="psw-repeat"  required/>

        <button type="submit" class="registerbtn">Register</button>

         </div>
    
    </div></form> 
    
  );
}