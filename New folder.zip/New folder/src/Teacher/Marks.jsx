import React from "react";
import "./new.scss";

const Marks =() =>{
    return(
        <>
        <div className="md-col-8 table">
        <table className="tabset">
  <tr className="tabset">
    <th className="tabset">Roll No</th>
    <th className="tabset">Name</th>
    <th className="tabset">Father Name</th>
    <th className="tabset">Attendance</th>
    <th className="tabset">Assig</th>
    <th className="tabset">Mid Term</th>
    <th className="tabset">Final</th>
  </tr >
  <tr className="tabset">
    <td className="tabset">18CS1</td>
    <td className="tabset">Shani</td>
    <td className="tabset">Arshad</td>
    <td className="tabset"> <input type="number" /> </td>
    <td className="tabset"> <input type="number" /> </td>
    <td className="tabset"> <input type="number" /> </td>
    <td className="tabset"> <input type="number" /> </td>
  </tr>
  <tr className="tabset">
    <td className="tabset">18CS2</td>
    <td className="tabset">Ahsan</td>
    <td className="tabset">Ali</td>
    <td className="tabset"> <input type="number" /> </td>
    <td className="tabset"> <input type="number" /> </td>
    <td className="tabset"> <input type="number" /> </td>
    <td className="tabset"> <input type="number" /> </td>
  </tr>
</table>

</div> <div className="doup"><button type="submit" className="btnup">Upload</button></div>
        </>
    );
}
export default Marks;